from service import login
from service import register, logout

while True:
    choice = input('choice : ')
    if choice == '1':
        username = input('username : ')
        password = input('password : ')
        
        result = login(username,password)
        
        print(result)


    elif choice == "2":
        username = input('Username : ')
        password = input('Password : ')
        result = register(username, password)
        print(result)

    elif choice == '3':
        result = logout()
        print(result)



    elif choice == 'q':
        break

    else:
        print("choose 1,2,3 or q(exit)!")

if __name__ == "__main__":
    print(register("homework", "home55"))
    print(logout("homework"))