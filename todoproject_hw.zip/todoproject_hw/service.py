from session import Session
from utils import Response, match_password
from db import cur, commit
from models import User
from db import conn, cur


session = Session()




def login(username : str, password : str):
    user = session.check_session()
    if user:
        return Response('You already logged in' , 404)
    
    get_user_by_username = '''select * from users where username = %s;'''
    cur.execute(get_user_by_username,(username,))
    
    user_data = cur.fetchone()
    if not user_data:
        return Response('User not found',404)
    
    
    user = User.from_tuple(user_data)
    
    
    if not match_password(password,user.password):
        return Response('Password wrong',404)
    
    session.add_session(user)
    return Response('You successfully logged in.')
    
    
    
    
def register(username: str, password: str):
    cur.execute("select id from users where username = %s", (username,))
    existing_user = cur.fetchone()

    if existing_user:
        return "This user has already been registered."

    cur.execute(
        "insert into users (username, password) values (%s, %s)",
        (username, password)

    )
    conn.commit()

    return f"User '{username} has successfully been registered."


def logout(username: str):
    return f"{username} has logged out."

    
